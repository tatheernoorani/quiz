<?php

$config = [
	'name' => __('Top Row', 'blocksy')
];