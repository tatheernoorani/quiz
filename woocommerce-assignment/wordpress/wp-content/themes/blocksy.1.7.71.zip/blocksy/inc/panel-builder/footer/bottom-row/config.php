<?php

$config = [
	'name' => __('Bottom Row', 'blocksy'),
	'typography_keys' => ['footerWidgetsTitleFont', 'footerWidgetsFont'],
];
