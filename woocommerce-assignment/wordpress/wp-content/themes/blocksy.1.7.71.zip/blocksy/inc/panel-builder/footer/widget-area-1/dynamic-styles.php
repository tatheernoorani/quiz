<?php
if (! isset($selector)) {
	$selector = '[data-column="widget-area-1"]';
}
