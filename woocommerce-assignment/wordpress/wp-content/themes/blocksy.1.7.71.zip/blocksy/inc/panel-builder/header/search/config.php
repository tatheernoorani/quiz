<?php

$config = [
	'name' => __('Search', 'blocksy'),
	'excluded_from' => ['offcanvas']
];

