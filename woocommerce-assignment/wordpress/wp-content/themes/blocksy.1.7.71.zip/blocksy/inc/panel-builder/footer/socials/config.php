<?php

$config = [
	'name' => __('Socials', 'blocksy'),
	'clone' => true,
];

