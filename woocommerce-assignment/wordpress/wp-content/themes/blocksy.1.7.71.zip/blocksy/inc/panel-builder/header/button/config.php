<?php

$config = [
	'name' => __('Button', 'blocksy'),
	'clone' => true,

	'translation_keys' => [
		[
			'key' => 'header_button_text',
			'multiline' => false
		],

		[
			'key' => 'header_button_link',
			'multiline' => false
		]
	]
];
